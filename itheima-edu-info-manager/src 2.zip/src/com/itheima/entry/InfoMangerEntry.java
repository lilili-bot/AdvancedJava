package com.itheima.entry;

import com.itheima.controller.StudentController;
import com.itheima.domain.Student;

import java.util.Scanner;

public class InfoMangerEntry {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        while (true) {
            // main menu building
            System.out.println("-----Welcome to Heima Information Manager");
            System.out.println("1. Student Manager 2. Teacher Manager 3. Exit");
            String choice = sc.next();
            // switch to different function.
            switch (choice) {
                case "1":
                    StudentController sContr = new StudentController();
                    sContr.start();
                    break;
                case "2":
                    System.out.println("TeacherManger()");
                    break;
                case "3":
                    System.out.println("Thanks for using Info System!");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Error occurred");
            }
        }
    }
}
